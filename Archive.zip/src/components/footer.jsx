
import './footer.css';

function Footer(){
    return (
        <div className="Footer">
            <h6>Footer info here</h6>
        </div>
    );
}
export default Footer;